const { GoogleGenerativeAI } = require('@google/generative-ai');
const config = require('./config');
const conversationStore = require('./conversationStore');

/**
 * AI Service - Professional Google Gemini Integration
 */
class AIService {
  constructor() {
    this.genAI = new GoogleGenerativeAI(config.GEMINI_API_KEY);
    this.model = this.genAI.getGenerativeModel({ model: "gemini-flash-latest" });
    console.log('✅ AI Service: Initialized with Google Gemini API');
  }

  async generateReply(userId, userMessage) {
    try {
      const prevHistory = conversationStore.getHistory(userId);
      
      // Initialize chat with history
      const chat = this.model.startChat({
        history: prevHistory.map(h => ({
          role: h.role === 'user' ? 'user' : 'model',
          parts: h.parts
        })),
        systemInstruction: { parts: [{ text: config.SYSTEM_PROMPT }] }
      });

      console.log(`🤖 Logic: Calling Gemini API for user ${userId}...`);

      const result = await chat.sendMessage(userMessage);
      const response = await result.response;
      const replyText = response.text();
      
      const cleanedResponse = this.cleanForWhatsApp(replyText);

      // Save to store
      conversationStore.addMessage(userId, 'user', userMessage);
      conversationStore.addMessage(userId, 'model', cleanedResponse);

      return cleanedResponse;
    } catch (error) {
      console.error('❌ AI Final Error:', error.message);
      return 'Main check karke batata hoon, server thoda busy hai! 🙏';
    }
  }

  async generateFollowUp(userId) {
    try {
      const result = await this.model.generateContent("Short Hinglish fitness check-in message for a user who stopped replying. Just one informal line.");
      const response = await result.response;
      return this.cleanForWhatsApp(response.text());
    } catch (err) {
      return 'Kaise chal raha hai workout? 💪';
    }
  }

  cleanForWhatsApp(text) {
    // WhatsApp styles: *bold*, _italic_, ~strikethrough~
    // Gemini often uses **bold**, which we convert to *bold*
    return text
      .replace(/\*\*(.*?)\*\*/g, '*$1*') // Convert **bold** to *bold*
      .replace(/##?\s*/g, '')           // Remove headers
      .replace(/`/g, '')                 // Remove backticks
      .trim();
  }
}

module.exports = new AIService();
